package animals;
import java.util.Observable;

import java.awt.Graphics;
import java.lang.Cloneable;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import diet.IDiet;
import food.EFoodType;
import food.IEdible;
import graphics.IAnimalBehavior;
import graphics.IColor;
import graphics.IDraw;
import graphics.IDrawable;
import graphics.ZooPanel;
import mobility.Mobile;
import mobility.Point;
import java.lang.Runnable;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * A class that defines an Animal.
 * @version April 2022
 *@author  Adi Buchris 206147647
 * 			Demi Netzer 323134577
 */
public abstract class Animal extends Observable implements IEdible, IDrawable, IAnimalBehavior,Runnable,IDraw {

	
	private final int EAT_DISTANCE = 10;
	private String name;
	private double weight;
	private IDiet diet;	
	private int size;
	private String col;
	private int horSpeed;
	private int verSpeed;
	private boolean coordChanged;
	protected int x_dir;
	protected int y_dir;
	private int eatCount;
	private ZooPanel pan;
	private BufferedImage img1, img2;
	private boolean onPanel;
	//protected Thread thread;
	private AtomicBoolean threadSuspended=new AtomicBoolean(false);
	//protected Point location;
	private String[] blueImgs = null;
	private String[] naturalImgs = null;
	private String[] redImgs = null;
	private EFoodType food=null;
	private boolean alive=true;
	private Mobile mobile;

	
	
	/******************************************************
	 *                   CONSTRUCTORS                     *
	 ******************************************************/
	
	/**
	 * Constructor for Animal object
	 * @param name 
	 * 				- Animal's name
	 * @param point 
	 * 				- Current location 
	 * @param weight
	 * 				- Animal's weight
	 * @param diet
	 * 			    - Animal's weight
	 * @param size 
	 * 				- Animal's weight
	 * @param horSpeed 
	 * 				- Animal's horizontal speed
	 * @param verSpeed 
	 * 				- Animal's vertical speed
	 * @param color 
	 * 				- Animal's color
	 * @param pan
	 *              - The panel of the zoo 
	 */
	public Animal(String name ,Point point, double weight, IDiet diet,
			int size, int horSpeed, int verSpeed, String color, ZooPanel pan) {
		this.mobile = new Mobile(point);
		this.name = name;
		this.weight = weight;
		this.diet = diet;
		this.size = size;
		this.horSpeed = horSpeed;
		this.verSpeed = verSpeed;
		this.col = color;
		this.eatCount = 0;
		this.coordChanged = false;
		this.x_dir = 1;
		this.y_dir = 1;
		this.pan = pan;
		this.onPanel = false;
		//this.thread=new Thread(this);
		pan.setEnabled(true);
	}
	
	public Object clone() {return null;}
	
	
	
	/******************************************************
	 *                     GETTERS                        *
	 ******************************************************/
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see graphics.IAnimalBehavior#getAnimalName
	 */
	public String getAnimalName(){
		return this.name;
	}
	
	
	/**
	 * A method that returns the weight of the animal
	 * @return weight of animal
	 */
	public synchronized double getWeight(){
		return this.weight;
	}
	
		
	/**
	 * A method that returns the diet of the animal
	 * @return diet of animal
	 */
	public IDiet getDiet() {
		return this.diet;
	}
	
	/**
	 * A method that returns the horizontal speed of the animal
	 * @return horizontal speed of the animal
	 */
	public int getHorSpeed() {
		return this.horSpeed;
	}
	
	/**
	 * A method that returns the vertical speed of the animal
	 * @return verticLal speed of the animal
	 */	
	public int getVerSpeed() {
		return this.verSpeed;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see graphics.IAnimalBehavior#getSize
	 */
	@Override
	public int getSize() {
		return this.size;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see food.IEdible#getFoodtype
	 */
	@Override
	public EFoodType getFoodtype() {
		return EFoodType.MEAT;
	}
	
	/**
	 * A method that returns the minimum distance
	 * from which an animal can eat food
	 * @return - the minimum distance
	 * 			 from which an animal can eat food
	 */
	public int getEatDistance() {
		return EAT_DISTANCE;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see graphics.IAnimalBehavior#getColor
	 */
	@Override
	public String getColor() {
		return this.col;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see graphics.IAnimalBehavior#getEatCount
	 */
	@Override
	public synchronized int getEatCount() {
		return this.eatCount;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see graphics.IAnimalBehavior#getChanges
	 */
	@Override
	public boolean getChanges() {
		return this.coordChanged;
	}
	
	/**
	 * A method that returns if the animal appears on the panel
	 * @return if the animal appears on the panel : True,
	 * 		   otherwise : False
	 */
	public synchronized boolean isOnPanel() {
		return onPanel;
	}

	/**
	 * A method that returns the panel the animal appears on it
	 * @return the panel the animal appears on it
	 */
	public ZooPanel getPan() {
		return this.pan;
	}
	
	/**
	 * A method that returns the image of the animal on the right
	 * @return image of the animal on the right
	 */
	public BufferedImage getImg1() {
		return this.img1;
	}
	
	/**
	 * A method that returns the image of the animal on the left
	 * @return image of the animal on the left
	 */
	public BufferedImage getImg2() {
		return this.img2;
	}

	/**
	 * A method that returns the direction of movement of the animal
	 * @return - the direction of movement of the animal
	 */
	public synchronized int getDirX() {
		return this.x_dir;
	}
	
	/**
	 * A method that returns the direction of movement of the animal
	 * @return - the direction of movement of the animal
	 */
	public synchronized int getDirY() {
		return this.y_dir;
	}

	/**
	 * A method that returns all the blue images
	 * @return -  all the blue images
	 */
	public String[] getBlueImgs() {
		return this.blueImgs;
	}

	/**
	 * A method that returns all the natural images
	 * @return -  all the natural images
	 */
	public String[] getNaturalImgs() {
		return this.naturalImgs;
	}

	/**
	 * A method that returns all the red images
	 * @return -  all the red images
	 */
	public String[] getRedImgs() {
		return this.redImgs;
	}
	public boolean getAlive() {
		return alive;
	}
	public Mobile getMobile() {
		return this.mobile;
	}

	
	/******************************************************
	 *                     SETTERS                        *
	 ******************************************************/
	
	
	public boolean setBlueImages(String [] imgs)
	{
		if (this.blueImgs == null)
			this.blueImgs = new String[2];
		this.blueImgs[0] = new String(imgs[0]);
		this.blueImgs[1] = new String(imgs[1]);		
		return true;
	}
	
	public boolean setNaturalImages(String [] imgs)
	{
		if (this.naturalImgs == null)
			this.naturalImgs = new String[2];
		this.naturalImgs[0] = new String(imgs[0]);
		this.naturalImgs[1] = new String(imgs[1]);		
		return true;
	}
	
	public boolean setRedImages(String [] imgs)
	{
		if (this.redImgs == null)
			this.redImgs = new String[2];
		this.redImgs[0] = new String(imgs[0]);
		this.redImgs[1] = new String(imgs[1]);		
		return true;
	}
	
	
	/**
	 * A method that defines a new name for an animal
	 * @param name
	 * 			- new name of the animal 
	 * @return true : If the setting was performed
	 */
	public  boolean setName(String name) {
		this.name = name;
		return true;
	}
	
	/**
	 * A method that defines a new weight for an animal
	 * @param w
	 * 			- new weight of the animal 
	 * @return If the setting was performed : true,
	 * 		   Otherwise : false.
	 */
	public synchronized boolean setWeight(double w) {
		if (w < 0) {
			//this.thread.interrupt();
			return false; }
		this.weight = w;
	
	
		return true;
	}
	
	/**
	 * A method that defines a new diet for an animal
	 * @param d
	 * 			- new diet of the animal 
	 * @return true : If the setting was performed
	 */
	public boolean setDiet(IDiet d) {
		return true;
	}
	
	
	/**
	 * A method that sets the image on the right side of the animal
	 * @param link - Image name without the path and without the image type
	 */
	public  void setImag1(String link) {
		try { this.img1 = ImageIO.read(new File(PICTURE_PATH+link+".png")); }
		catch (IOException e) { System.out.println("Cannot load image"); }
	}
	
	/**
	 * A method that sets the image on the left side of the animal
	 * @param link - Image name without the path and without the image type
	 */
	public  void setImag2(String link) {
		try { this.img2 = ImageIO.read(new File(PICTURE_PATH+link+".png")); }
		catch (IOException e) { System.out.println("Cannot load image"); }
	}
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see graphics.IAnimalBehavior#setChanges
	 */
	@Override
	public  void setChanges(boolean state) {
		this.coordChanged = state;
	}

	/**
	 * A method that defines the panel on which the animal will appear
	 * @param pan
	 * 			- panel on which the animal will appear
	 */
	public void setPanel(ZooPanel pan) {
		this.pan = pan;
	}
	

	/**
	 * A method that defines whether the animal appears on the panel or not
	 * @param bool
	 */
	public synchronized void setOnPanel(boolean bool) {
		this.onPanel = bool;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see graphics.IAnimalBehavior#eatInc()
	 */
	@Override
	public synchronized void eatInc() {
		this.eatCount+=1;
		
	}
	/**
	 * A method that sets if the thread is alive
	 * @param alive - boolean
	 */
	public synchronized void setAlive(boolean alive) {
		this.alive=alive;
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see graphics.IAnimalBehavior#getColor
	 */
	public synchronized void setColor(String color) {
		this.col=color;
	}
	public void draw(String color) {
		this.setColor(color);
	}
	
	/******************************************************
	 *                  OTHER METHODS                     *
	 ******************************************************/
	

	
	public double move(Point p) {
		double dis = this.mobile.move(p);
		if (dis == 0)
			return 0;
		this.setWeight(this.getWeight()
		- (dis*this.getWeight()*0.00025));
		this.coordChanged=true;
		return dis;
	}
	
	/**
	 * A method that gets food and returns 
	 * true if the animal ate the food
	 * @param diet 
	 * 			  -  food for the animal
	 * @return If the animal eats this type of food : true,
	 * 		   otherwise: false
	 */
	public synchronized boolean eat(IEdible diet) {
		double additional_w = this.getDiet().eat(this, diet);
		if (additional_w == 0) {
			return false;
		}
		this.setWeight(getWeight() + additional_w);
		this.eatInc();
		return true;
	}

	/**
	 * A method that activates the animal's voice.
	 */
	public void makeSound() {}

	/*
	 * (non-Javadoc)
	 * 
	 * @see  graphics.IDrawable#loadImages(String nm)
	 */	
	@Override
	public void loadImages(String nm) {
		if (nm == "Blue" ) {
			this.setImag1(this.getBlueImgs()[0]);
			this.setImag2(this.getBlueImgs()[1]);
		}
		if (nm == "Natural") {
			this.setImag1(this.getNaturalImgs()[0]);
			this.setImag2(this.getNaturalImgs()[1]);
		}
		if (nm == "Red" ) {
			this.setImag1(this.getRedImgs()[0]); 
			this.setImag2(this.getRedImgs()[1]);
		}
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see  graphics.IDrawable#drawObject(Graphics g)
	 */	
	@Override
	public abstract void drawObject(Graphics g);
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "[Animal] : " + this.getAnimalName();
	}


	/**
	 * A method that returns the animal's thread
	 * @return thread
	 */
	/*public Thread getThread() {
		return this.thread;
	}
	*/
	/**
	 * A method that returns the if the thread is suspended
	 * @return threadSuspended-boolean
	 */
	public synchronized boolean getThreadSuspended() {
		return threadSuspended.get();
	}
	/**
	 * A method that sets the thread to be suspended
	 * 
	 */
	public synchronized void setSuspended(boolean state) {
		threadSuspended.set(state);
	}
	/**
	 * A method that sets the thread to be resumed
	 * 
	 */
	public synchronized void setResumed(boolean state) {
		threadSuspended.set(state);		
	}
	public synchronized void setResumed() {
		threadSuspended.set(false);
	}
	public synchronized void setSuspended() {
		threadSuspended.set(true);
	}
	/**
	 * A method that changes x direction 
	 */
	public synchronized void changeDirX() {
		this.x_dir*=-1;
	}
	/**
	 * A method that returns the x value
	 * @return x value
	 */
	public int getNewX() {
			if(this.thereIsFood()) {
					if(this.thereIsFood()) {
						if ((this.getDirX()==1 && this.mobile.getLocation().getX() > (this.pan.getWidth()/2+25))||
								(this.getDirX() == -1 && this.mobile.getLocation().getX() < (this.pan.getWidth()/2-25))) {
							System.out.println(this.mobile.getLocation()+" newXChange");
							this.changeDirX();
						}
			}
				
			}
			
		return this.mobile.getLocation().getX() + this.horSpeed * this.x_dir;
	}
	/**
	 * A method that returns the y value
	 * @return y value
	 */
	public int getNewY(int newX) {
		if (this.thereIsFood()) {
				
					int m = (this.mobile.getLocation().getY()- this.getPan().getHeight()/2)/
							(this.mobile.getLocation().getX()- this.getPan().getWidth()/2);
					int n = this.mobile.getLocation().getY()-(m*this.mobile.getLocation().getX());
					return newX*m + n;	
				
			
	
		}
		return this.mobile.getLocation().getY() + this.verSpeed * this.y_dir;
	}
	
	/**
	 * a method that returns if there is an appropriate food on the panel
	 * @return
	 */
	public boolean thereIsFood() {
		if(this.diet.canEat(this.pan.getFoodType())==true)
			return true;
		return false;
	}
	
	
	@Override
	public void run() {
		
		while(this.alive==true) {
			
			int newX = this.getNewX();
			int newY = this.getNewY(newX);
			System.out.println("runnnnnnnnnn  "+this.name);
			System.out.println(newX+" |"+ newY);
			System.out.println(this.mobile.getLocation());
			System.out.println(this.alive);
			
			
			
			if(threadSuspended.get()==true) {
				synchronized(this) {
				try{
					this.wait();
				    }catch (InterruptedException e){}
				}
			}
			
			if(newX>800||newX<0) 
				this.x_dir=this.x_dir*-1;
	
			if(newY>=600||newY<0) 
				this.y_dir = this.y_dir*-1;
			
			//this.location=new Point(newX,newY);
			
			this.move(new Point(newX,newY));
			if(this.thereIsFood()) {
				System.out.println("first for");
				System.out.println("lion :" + /*this.location*/  "|" + this.mobile.getLocation() +"|"+ this.getPan().getWidth()/2 + "," + this.getPan().getHeight()/2);				
				double currentDis= this.mobile.calcDistance(new Point(this.getPan().getWidth()/2/*+((this.getDirX()==1)?0:this.size/2)*/,
						this.getPan().getHeight()/2));
				System.out.println(currentDis);
				if(currentDis<= this.getEatDistance()) {
					System.out.println("second for");
					this.pan.tryEatFood(this);
				}
			}
			
			//this.pan.repaint();
			try{
				Thread.sleep((long)(100));
			    }catch (InterruptedException e){}
			System.out.println("sleep?????");
			//this.pan.repaint();
			this.setChanged();
			this.notifyObservers();

		}
	
		
	}

}







