package animals;

import java.awt.Graphics;
import diet.IDiet;
import diet.Omnivore;
import food.IEdible;
import graphics.ZooPanel;
import mobility.Point;

/**
 * A class that defines a Bear.
 * @version April 2022
 *@author  Adi Buchris 206147647
 * 			Demi Netzer 323134577
 */
public class Bear extends Animal{

	private static final Point default_p = new Point(100,5); // default location 
	private static final double default_w = 308.2; // default weight
	private static final IDiet default_d = new Omnivore(); // default diet of a bear
	private static final String[] blueImgs = {"bea_b_1", "bea_b_2"};
	private static final String[] naturalImgs = {"bea_n_1", "bea_n_2"};
	private static final String[] redImgs = {"bea_r_1", "bea_r_2"};
			
	
	/******************************************************
	 *                   CONSTRUCTORS                     *
	 ******************************************************/
	
	/**
	 * Constructor for Bear object
	 * @param size 
	 * 				- Bear's weight
	 * @param horSpeed 
	 * 				- Bear's horizontal speed
	 * @param verSpeed 
	 * 				- Bear's vertical speed
	 * @param color 
	 * 				- Bear's color
	 */
	public Bear(int size, int horSpeed, int verSpeed, String color, ZooPanel pan) {
		super("Bear", default_p, 1.5*size, default_d, size, horSpeed, verSpeed, color, pan);	
		this.setBlueImages(blueImgs);
		this.setNaturalImages(naturalImgs);
		this.setRedImages(redImgs);
		//this.location=new Point(this.getLocation().getX()-this.getSize()/2,
			//this.getLocation().getY()-this.getSize()/2);
		
	}
	
	public Object clone() {
		Bear temp = new Bear(this.getSize(),this.getHorSpeed(),this.getVerSpeed(),this.getColor(), this.getPan());
		temp.getMobile().setLocation(this.getMobile().getLocation());
		temp.x_dir = this.x_dir;
		temp.y_dir = this.y_dir;
		temp.setOnPanel(getAlive());
		temp.setSuspended(this.getThreadSuspended());
		return temp;
	}
	
	/******************************************************
	 *                  OTHER METHODS                     *
	 ******************************************************/
		
	/*
	 * (non-Javadoc)
	 * 
	 * @see animals.Animal.drawObject(Graphics g)
	 */
	@Override
	public void drawObject (Graphics g)
	{
		 if(this.getDirX()==1) // bear goes to the right side
			 g.drawImage(this.getImg1(), this.getMobile().getLocation().getX()-this.getSize()/2,
					 this.getMobile().getLocation().getY()-this.getSize()/2, this.getSize()/2, this.getSize(), this.getPan());
		 else // bear goes to the left side
			 g.drawImage(this.getImg2(), this.getMobile().getLocation().getX(),
					 this.getMobile().getLocation().getY()-this.getSize()/2, this.getSize()/2, this.getSize(), this.getPan());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "[Bear] : " + this.getAnimalName();
	}
}
