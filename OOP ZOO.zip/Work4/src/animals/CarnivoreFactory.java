package animals;

import graphics.ZooPanel;

public class CarnivoreFactory implements IAnimalFactory  {

	
	@Override
	public Animal createAnimal(String type, int size, int horSpeed, int verSpeed, String color, ZooPanel pan) {
		if (type == "Lion") {
			return new Lion(size, horSpeed, verSpeed, color, pan);
		}
		return null;
		}
}
