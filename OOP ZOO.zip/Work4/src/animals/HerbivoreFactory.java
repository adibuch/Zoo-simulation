package animals;

import graphics.ZooPanel;

public class HerbivoreFactory implements IAnimalFactory {

	@Override
	public Animal createAnimal(String type, int size, int horSpeed, int verSpeed, String color, ZooPanel pan) {
		if (type == "Turtle") {
			return new Turtle(size, horSpeed, verSpeed, color, pan);
		}
		if (type == "Elephant") {
			return new Elephant(size, horSpeed, verSpeed, color, pan);
		}
		if (type == "Giraffe") {
			return new Giraffe(size, horSpeed, verSpeed, color, pan);
		}
		return null;
	}
}
