package animals;

import graphics.ZooPanel;

public interface IAnimalFactory {
	
	public Animal createAnimal(String type, int size, int horSpeed, int verSpeed, String color, ZooPanel pan);


}
