package animals;

import java.awt.Graphics;
import java.lang.Math;
import diet.Carnivore;
import diet.IDiet;
import food.EFoodType;
import food.IEdible;
import graphics.ZooPanel;
import mobility.Point;

/**
 * A class that defines a Lion.
 * @version April 2022
 * @author  Adi Buchris 206147647
 * 			Demi Netzer 323134577
 */
public class Lion extends Animal {
	
	private int scarCount; // number of scars
	private static final int default_s = 0; // default number of scars
	private static final Point default_p = new Point(20,0); // default location of a lion
	private static final double default_w = 408.2; // default weight of a lion
	private static final IDiet default_d = new Carnivore(); // default diet of a lion
	private static final String[] blue = {"lio_b_1", "lio_b_2"};
	private static final String[] natural = {"lio_n_1", "lio_n_2"};
	private static final String[] red = {"lio_r_1", "lio_r_2"};
	

	
	/******************************************************
	 *                   CONSTRUCTORS                     *
	 ******************************************************/
	
	/**
	 * Constructor for Lion object
	 * @param size 
	 * 				- Lion's weight
	 * @param horSpeed 
	 * 				- Lion's horizontal speed
	 * @param verSpeed 
	 * 				- Lion's vertical speed
	 * @param color 
	 * 				- Lion's color
	 */
	public Lion(int size, int horSpeed, int verSpeed, String color, ZooPanel pan) {
		super("Lion", default_p, 0.8*size, default_d, size, horSpeed, verSpeed, color, pan);	
		this.scarCount = default_s;
		this.setBlueImages(blue);
		this.setNaturalImages(natural);
		this.setRedImages(red);
		//this.location=new Point(this.getLocation().getX()-this.getSize()/2,
			//	this.getLocation().getY()-this.getSize()/3);
		//System.out.println("----------------"+location);

	}
	
	public Object clone() {
		Lion temp = new Lion(this.getSize(),this.getHorSpeed(),this.getVerSpeed(),this.getColor(), this.getPan());
		temp.getMobile().setLocation(this.getMobile().getLocation());
		temp.x_dir = this.x_dir;
		temp.y_dir = this.y_dir;
		temp.setOnPanel(getAlive());
		temp.setSuspended(this.getThreadSuspended());
		return temp;
	}
	

	/******************************************************
	 *                     GETTERS                        *
	 ******************************************************/
	
	/**
	 * A method that returns the number of scars of the lion
	 * @return number of scars
	 */
	public int getScarCount() {
		return this.scarCount;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see food.IEdible#getFoodtype
	 */
	@Override
	public EFoodType getFoodtype() {
		return EFoodType.NOTFOOD;
	}
	
	
	/******************************************************
	 *                     SETTERS                        *
	 ******************************************************/
	
	/**
	 * A method that defines a new number of scars for the lion.
	 * @param s
	 * 			- new number of scars
	 * @return If the setting was performed : true,
	 * 		   Otherwise : false.
	 */
	public boolean setScarCount(int s) {
		if (s < 0) {
			return false;
		}
		this.scarCount = s;
		return true;
	}
	
	
	/******************************************************
	 *                  OTHER METHODS                     *
	 ******************************************************/
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see animals.Animal#eat
	 */
	@Override
	public boolean eat(IEdible diet) {
		if (super.eat(diet)) {
			if (Math.random() > 0.5) {
				this.setScarCount(this.getScarCount()+1);
			}
			return true;
		}
		return false;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "[Lion] : " + this.getAnimalName();
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see animals.Animal.drawObject(Graphics g)
	 */
	@Override
	public void drawObject (Graphics g)
	{
		
		 if(this.getDirX()==1) // bear goes to the right side
			 g.drawImage(this.getImg1(), this.getMobile().getLocation().getX()-this.getSize()/2, this.getMobile().getLocation().getY()-this.getSize()/3, this.getSize()/2, this.getSize(), this.getPan());
		 else // bear goes to the left side
			 g.drawImage(this.getImg2(), this.getMobile().getLocation().getX(), this.getMobile().getLocation().getY()-this.getSize()/3, this.getSize()/2, this.getSize(), this.getPan());
	}
}
