package animals;

import graphics.ZooPanel;

public class OmnivoreFactory implements IAnimalFactory {
	
	@Override
	public Animal createAnimal(String type, int size, int horSpeed, int verSpeed, String color, ZooPanel pan) {
		if (type == "Bear") {
			return new Bear(size, horSpeed, verSpeed, color, pan);
		}
		return null;
	}

}
