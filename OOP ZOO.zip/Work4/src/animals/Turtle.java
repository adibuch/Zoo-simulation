package animals;

import java.awt.Graphics;
import diet.Herbivore;
import diet.IDiet;
import graphics.ZooPanel;
import mobility.Point;

/**
 * A class that defines a Turtle.
 * @version April 2022
 * @author  Adi Buchris 206147647
 * 			Demi Netzer 323134577
 */
public class Turtle extends Animal {

	private int age;
	private static final Point default_p = new Point(80,0); // default location of turtle
	private static final double default_w = 1; // default weight of turtle
	private static final IDiet default_d = new Herbivore();  // default diet of turtle
	private static final int default_age = 1; // default age of turtle
	private static final String[] blue = {"trt_b_1", "trt_b_2"};
	private static final String[] natural = {"trt_n_1", "trt_n_2"};
	private static final String[] red = {"trt_r_1", "trt_r_2"};
	
	
	/******************************************************
	 *                   CONSTRUCTORS                     *
	 ******************************************************/
	
	/**
	* Constructor for Turtle object
	* @param size 
	* 				- Turtle's weight
	* @param horSpeed 
	* 				- Turtle's horizontal speed
	* @param verSpeed 
	* 				- Turtle's vertical speed
	* @param color 
	* 				- Turtle's color
	*/	
	public Turtle(int size, int horSpeed, int verSpeed, String color, ZooPanel pan) {
		super("Turtle", default_p, 0.5*size, default_d, size, horSpeed, verSpeed, color, pan);	
		this.age = default_age;
		this.setBlueImages(blue);
		this.setNaturalImages(natural);
		this.setRedImages(red);
		//this.location=new Point(this.getLocation().getX()-this.getSize()/2,
			//	this.getLocation().getY()-this.getSize()/4*3);
	}
	
	
	public Object clone() {
		Turtle temp = new Turtle(this.getSize(),this.getHorSpeed(),this.getVerSpeed(),this.getColor(), this.getPan());
		temp.getMobile().setLocation(this.getMobile().getLocation());
		temp.x_dir = this.x_dir;
		temp.y_dir = this.y_dir;
		temp.setOnPanel(getAlive());
		temp.setSuspended(this.getThreadSuspended());
		return temp;
	}
	
	/******************************************************
	 *                     GETTERS                        *
	 ******************************************************/
	
	/**
	 * A method that returns the turtle's age
	 * @return age
	 */
	public int getAge() {
		return this.age;
	}
	
	/******************************************************
	 *                     SETTERS                        *
	 ******************************************************/
	
	/**
	 * A method that defines a new age for the turtle.
	 * @param age
	 * 			- new age
	 * @return If the setting was performed : true,
	 * 		   Otherwise : false.
	 */
	public boolean setAge(int age) {
		if (age >= 1 && age <= 500) {
			this.age = age;
			return true;
		}
		return false;
	}
	
	
	/******************************************************
	 *                  OTHER METHODS                     *
	 ******************************************************/
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "[Turtle] : " + this.getAnimalName();
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see animals.Animal.drawObject(Graphics g)
	 */
	@Override
	public void drawObject (Graphics g)
	{
		
		 if(this.getDirX()==1) // bear goes to the right side
			 g.drawImage(this.getImg1(), this.getMobile().getLocation().getX()-this.getSize()/2, this.getMobile().getLocation().getY()-this.getSize()/4*3, this.getSize()/2, this.getSize(), this.getPan());
		 else // bear goes to the left side
			 g.drawImage(this.getImg2(), this.getMobile().getLocation().getX(), this.getMobile().getLocation().getY()-this.getSize()/4*3, this.getSize()/2, this.getSize(), this.getPan());
	}

}
