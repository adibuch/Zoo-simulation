package graphics;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import animals.Animal;
import animals.Bear;
import animals.CarnivoreFactory;
import animals.Elephant;
import animals.Giraffe;
import animals.HerbivoreFactory;
import animals.IAnimalFactory;
import animals.Lion;
import animals.OmnivoreFactory;
import animals.Turtle;

/**
 * A class for creating a dialog Window for creating animals  
 * @version April 2022
 * @author  Adi Buchris 206147647
 * 			Demi Netzer 323134577
 */
public class AddAnimalDialog extends JDialog implements ActionListener{
	
	final static String [] ANIMAL_DIET= {"Omnivore", "Carnivore", "Herbivore"};
	
	
	
	private String [] ANIMALS= {"Lion", "Elephant","Giraffe","Turtle","Bear" };	
	private ArrayList<String> animalsKinds = new ArrayList<String>();

	
	final static String [] CARNIVORES= {"Lion"};
	final static String [] HERBIVORES= {"Elephant","Giraffe","Turtle"};
	final static String [] OMNIVORES= {"Bear"};

	final static JComboBox<String> carnivore_animals = new JComboBox<String>(CARNIVORES);
	final static JComboBox<String> herbivore_animals = new JComboBox<String>(HERBIVORES);
	final static JComboBox<String> omnivore_animals = new JComboBox<String>(OMNIVORES);
	
	final static String [] COLOR= {"Blue","Red","Natural"};
	
	private JLabel lblAnimalDiet, lblKindAnimal, lblSize,lblhorSpeed,lblverSpeed,lblColor,lblTitle;
	private JTextField txtsize,txthorSpeed,txtverSpeed;

	private JComboBox<String> cbDiet;
	private JComboBox<String> cbAnimal;
	private JComboBox<String> cbColor;
	
	private JButton btmAddAnimal;
	private JPanel p=null,p1=null;
	String animalKind=null,Color=null, animalDiet= null;
	String str1="";
	int size, horSpeed, verSpeed;
	private CopyOnWriteArrayList<Animal>animals;
	private ZooPanel pan = null;
	
	/**
	 * constructor
	 * @param arr 
	 * 			- An array of animals 
	 * @param pan
	 * 			- The main panel 
	 */
	public AddAnimalDialog(CopyOnWriteArrayList<Animal>arr, ZooPanel pan) {
		
		setSize(400,550);
		Font f=new Font("David",Font.PLAIN,20);

		this.pan=pan;
		this.animals=arr;
		
		cbDiet=new JComboBox<String>(ANIMAL_DIET);
		cbDiet.setSelectedItem(null);
		cbDiet.addActionListener(this);
		
		
		//initialize jcomboBox to select diet of Animal
		cbAnimal=new JComboBox<String>();
		cbAnimal.setEnabled(false);
		cbAnimal.setSelectedItem(null);
		cbAnimal.addActionListener(this);
		


		//initialize jcomboBox to select color of Animal
		cbColor=new JComboBox<String>(COLOR);
		cbColor.setSelectedItem(null);
		cbColor.addActionListener(this);
		
		//create animals input panel
		lblTitle=new JLabel("                Animal details        ");
		lblTitle.setFont(new Font("David",Font.BOLD,24));
		
		lblAnimalDiet = new JLabel(" Animal Diet :");
		lblAnimalDiet.setFont(f);
		
		lblKindAnimal=new JLabel(" Animal Kind :");
		lblKindAnimal.setFont(f); 
		
		lblSize=new JLabel(" Size :");
		lblSize.setFont(f);
		
		lblhorSpeed=new JLabel(" Horizontal speed :");
		lblhorSpeed.setFont(f);
		
		lblverSpeed=new JLabel(" Vertical speed :");
		lblverSpeed.setFont(f);
		
		lblColor=new  JLabel(" Color :");
		lblColor.setFont(f);
		
		txtsize=new JTextField();
		//txtsize.setEnabled(false);
		txthorSpeed=new JTextField();
		//txthorSpeed.setEnabled(false);
		txtverSpeed=new JTextField();
		//txtverSpeed.setEnabled(false);
		
		//init panel
		p=new JPanel();
		p.setLayout(new GridLayout(6,6));
		
		//adding to panel
		p.add(lblAnimalDiet); p.add(cbDiet);
		p.add(lblKindAnimal); p.add(cbAnimal);
		
		p.add(lblSize); p.add(txtsize);
		p.add(lblhorSpeed); p.add(txthorSpeed);
		p.add(lblverSpeed); p.add(txtverSpeed);
		p.add(lblColor);p.add(cbColor);

		//"Add animal" button
		btmAddAnimal=new JButton("Add animal");
		btmAddAnimal.setEnabled(false);
		btmAddAnimal.addActionListener(this);
		
		//panel for "Add animal" button
		JPanel pButton=new JPanel();
		pButton.setLayout(new BorderLayout());
		pButton.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
		pButton.add(btmAddAnimal,BorderLayout.CENTER);
		
		//The main panel
		p1=new JPanel();
		p1.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
		p1.setLayout(new BorderLayout());
		p1.add(lblTitle,BorderLayout.NORTH);
		p1.add(p,BorderLayout.CENTER);

		setLayout(new BorderLayout());
		add(p1,BorderLayout.CENTER);
		add(pButton, BorderLayout.SOUTH);
		setLocationRelativeTo(getParent());
		setVisible(true);	
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.event.ActionListener#actionPerformed(ActionEvent e)
	 */
	@Override
	public void actionPerformed(ActionEvent event) {
		
		// String for error messages
		String str="";
		
		if(event.getSource() == cbDiet) {

			animalDiet = (String)cbDiet.getSelectedItem();
			cbDiet.setEnabled(false);
			
			System.out.println(animalDiet);
			if (animalDiet.equals("Omnivore")) {
				cbAnimal.addItem("Bear");
				}
			if (animalDiet == "Carnivore") {
				cbAnimal.addItem("Lion");
			}
			if (animalDiet == "Herbivore") {
				cbAnimal.addItem("Turtle");
				cbAnimal.addItem("Elephant");
				cbAnimal.addItem("Giraffe");
			}
			
			cbAnimal.setSelectedItem(null);			
			cbAnimal.setEnabled(true);		
		}
		
		if(event.getSource()==cbAnimal) {
			animalKind = (String)cbAnimal.getSelectedItem();
		}
		if(event.getSource()==cbColor) 
			Color = (String)cbColor.getSelectedItem();
		
		if(Color != null && animalKind != null)
			btmAddAnimal.setEnabled(true);
		
		if(event.getSource()==btmAddAnimal) {
			
			try {
				size=Integer.parseInt(txtsize.getText());
				if(size<50||size>300) {
					str+="\n>>> size must be between 50-300 number!\nDefault value set to 50 fixel";
					size=50;
				}
			}
			catch(Exception e) {
				str+="\n>>> size must be a positive number!\nDefault value set to 50 fixel";
				size=50;
			}
			
			try {
				horSpeed=Integer.parseInt(txthorSpeed.getText());
				if(horSpeed<1||horSpeed>10) {
					str+="\n>>> horSpeed must be between 1-10 number!\nDefault value set to 1";
					horSpeed=1;
				}
			}
			catch(Exception e) {
				str+="\n>>> horSpeed must be a positive number!\nDefault value set to 1";
				horSpeed=1;
			}
			
			try {
				verSpeed=Integer.parseInt(txtverSpeed.getText());
				if(verSpeed<1||verSpeed>10) {
					str+="\n>>> verSpeed must be between 1-10 number!\nDefault value set to 1";
					horSpeed=1;
				}
			}
			catch(Exception e) {
				str+="\n>>> verSpeed must be a positive number!\nDefault value set to 1";
				verSpeed=1;
			}

			setVisible(false);
			
			// Print all error messages
			if(str!="") {
				JOptionPane.showMessageDialog(btmAddAnimal,str+str1);
			}
			
			// Add animal to array after initializing all of it fields
			AddAnimalToArray();
		}
	}
	
	private static IAnimalFactory createAnimalFactory(String diet)
	{
		if (diet == "Herbivore") {return new HerbivoreFactory();}
		if (diet == "Omnivore") {return new OmnivoreFactory();}
		if (diet == "Carnivore") {return new CarnivoreFactory();}
		return null;
	}
	
	/**
	 * Creating the new animal and adding it to the Animal's array
	 */
	private void AddAnimalToArray() {
		Animal a = createAnimalFactory(animalDiet).createAnimal(animalKind, size, horSpeed, verSpeed, Color, pan);
		
		
		/*	
		// Reference to the new Animal
		Animal a = null;
		
		// Create the new animal according to the user's choice
		switch(animalKind) {
		
			case "Lion":
				a=new Lion(size,horSpeed,verSpeed,Color,pan);				
				break;
				
			case "Bear":
				a=new Bear(size,horSpeed,verSpeed,Color,pan);				
				break;
				
			case "Elephant":
				a=new Elephant(size,horSpeed,verSpeed,Color,pan);				
				break;
			
			case "Giraffe":
				a=new Giraffe(size,horSpeed,verSpeed,Color,pan);				
				break;
			
			case "Turtle":
				a=new Turtle(size,horSpeed,verSpeed,Color,pan);
				break;
		}
		*/
		
		//set animal on panel
		a.setOnPanel(true);
		this.pan.getQueue().execute(a);
		
		a.addObserver(pan.getController());
		
		//add the new animal to the Animal's array
		animals.add(a);
		this.pan.repaint();
	}
}
