package graphics;

import java.util.Stack;
import java.util.concurrent.CopyOnWriteArrayList;

public class Caretaker {
	private ZooPanel window;
	private History history = new History();
	public Caretaker(ZooPanel window) { this.window = window; }
	private class History {
		private Stack<Memento> m_undo = new Stack<>();;
		
		public void save() {
			m_undo.push(window.save());
			System.out.println(m_undo );
			
		}
	
		public void undo() {
		
			window.restore(m_undo.pop());
			
		}
		public int getSizeArray() {return m_undo.size();}
		
		

	}
	public void hitSave() { history.save(); }
	public int getSize() {return history.getSizeArray();}
	public void hitUndo() { history.undo(); }
}
