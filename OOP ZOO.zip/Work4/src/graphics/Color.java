package graphics;

import javax.swing.JDialog;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import animals.Animal;
import animals.Bear;
import animals.Elephant;
import animals.Giraffe;
import animals.Lion;
import animals.Turtle;
import mobility.Point;


public class Color extends JDialog implements ActionListener {
	
	final static String [] COLOR= {"Blue","Red","Natural"};
	private ArrayList<String>animalsRepresent;
	private JLabel lblTitle, lblAnimal, lblColor;
	//private JTextField txtNewX,txtNewY;
	private ZooPanel pan = null;
	private JComboBox<String> cbAnimal ;
	private JComboBox<String> cbColor;
	private CopyOnWriteArrayList<Animal>animals;
	private JButton btmSetColor;
	private String index,color;
	int index2;
	String str1="";
	public Color(CopyOnWriteArrayList<Animal>arr, ZooPanel pan) {
		
		if (arr.size() == 0)
			return;
		animals=new CopyOnWriteArrayList<Animal>();
		this.animals=arr;
		this.pan=pan;
		setSize(400,300);

		System.out.println(arr.size());
		animalsRepresent = new ArrayList<String>();
		
		for (int i = 0; i < Math.min(arr.size(),10); i++) {
			animalsRepresent.add((i+1)+" Kind : " + arr.get(i).getAnimalName() +
					", Color : " + arr.get(i).getColor() + ", Location : (" + arr.get(i).getMobile().getLocation().getX() + ","
					+ arr.get(i).getMobile().getLocation().getY() + ")" );
		}
		cbAnimal = new JComboBox<String>(animalsRepresent.toArray(new String[animalsRepresent.size()]));
		cbAnimal.setSelectedItem(null);
		cbAnimal.addActionListener(this);
		
		cbColor=new JComboBox<String>(COLOR);
		cbColor.setSelectedItem(null);
		cbColor.addActionListener(this);

		lblTitle=new JLabel("SET COLOR");
		lblTitle.setFont(new Font("David",Font.BOLD,24));
		
		lblAnimal=new JLabel("Choose Animal :");		
		lblColor=new JLabel("New color :");		
		
		
		//init panel
		JPanel p = new JPanel();
		p.setLayout(new GridLayout(5,5));
				
		//adding to panel
		p.add(lblAnimal); p.add(cbAnimal);
		p.add(lblColor); p.add(cbColor);
		
		
		//add animal btm
		btmSetColor= new JButton("Set color");
		btmSetColor.setEnabled(false);
		btmSetColor.addActionListener(this);
				
		//panel for btm
		JPanel pButton=new JPanel();
		pButton.setLayout(new BorderLayout());
		pButton.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
		pButton.add(btmSetColor,BorderLayout.CENTER);
				
		//the main panel
		JPanel p1=new JPanel();
		p1.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
		p1.setLayout(new BorderLayout());
		p1.add(lblTitle,BorderLayout.NORTH);
		p1.add(p,BorderLayout.CENTER);

		setLayout(new BorderLayout());
		add(p1,BorderLayout.CENTER);
		add(pButton, BorderLayout.SOUTH);
		setLocationRelativeTo(getParent());
		setVisible(true);
		
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		String str="";
		// TODO Auto-generated method stub
		if(event.getSource()==cbAnimal) {
			index= (String)cbAnimal.getSelectedItem();
			index=index.substring(0, 1);
			index2=Integer.parseInt(index)-1;
		}

		if(event.getSource()==cbColor) 
			color = (String)cbColor.getSelectedItem();
		
		if(color != null && index != null)
			btmSetColor.setEnabled(true);
		
		
		if(event.getSource()==btmSetColor) {
			new ColorDecorator(animals.get(index2)).setColor(color);
			setVisible(false);
			}
			
		
		
		
	
	}

	}





