package graphics;

public class ColorDecorator extends DrawDecorator  {
	
	public ColorDecorator(IDraw otherAnimal) {
		super(otherAnimal);
	}
	public void draw(String color) {
		
		super.draw(color);
		System.out.println("Color");
		
	}
	public void setColor(String color) {
		this.draw(color);
		
	}
	
}
