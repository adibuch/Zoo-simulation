package graphics;

import java.util.Observable;
import java.util.Observer;

public class Controller implements Observer {

	private ZooPanel pan;
	
	public Controller(ZooPanel pan) {
		this.pan = pan;	
	}
	
	public Object clone() {
		return new Controller(this.pan);
	}
	
	@Override
	public void update(Observable o, Object arg) {
		System.out.println("update");
		if (pan.isAlive()) {
			
			System.out.println("isAlive");
			pan.tryEatAnimal();
			pan.repaint();
		}
	}
}
