package graphics;

public abstract class DrawDecorator implements IDraw {
	
	private IDraw animal;
	
	
	public DrawDecorator(IDraw otherAnimal) {
		this.animal=otherAnimal;
	}
	public void draw(String color) {
		animal.draw(color);
	}
	
}
