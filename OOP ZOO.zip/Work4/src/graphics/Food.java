package graphics;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;

import food.IEdible;
import plants.Cabbage;
import plants.Lettuce;
import plants.Plant;

/**
 * A class for creating a dialog Window for creating food  
 * @version April 2022
 * @author  Adi Buchris 206147647
 * 			Demi Netzer 323134577
 */
public class Food extends JDialog implements ActionListener {
	
	private JButton cabbage,lettuce,meat;
	private JLabel title;
	
	ZooPanel pan= null;
	private FoodSingleton food;
	//private IEdible food;
	/**
	 * Constructor
	 * @param fmeat
	 * 				- ArrayList of Meat
	 * @param plant
	 * 				- ArrayList of Plant
	 * @param pan
	 * 				- The main Panel
	 */
	Food(FoodSingleton food, ZooPanel pan)
	{
		this.pan = pan;
		this.food=food;
		setSize(400,200);
		title = new JLabel("               Please choose food:\n");
				
		//init panel
		JPanel p1 = new JPanel();
		JPanel p=new JPanel();
		p.setLayout(new GridLayout(1,3));
		
		lettuce= new JButton("lettuce");
		p.add(lettuce);
		lettuce.addActionListener(this);
		cabbage= new JButton("Cabbage");
		p.add(cabbage);
		cabbage.addActionListener(this);
		meat= new JButton("meat");
		p.add(meat); 
		meat.addActionListener(this);
		
		//the main panel
		p1.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
		p1.setLayout(new BorderLayout());
		p1.add(title,BorderLayout.NORTH);
		p1.add(p,BorderLayout.SOUTH);


		setLayout(new BorderLayout());
		add(p1,BorderLayout.CENTER);
	

		setLocationRelativeTo(getParent());
		this.setVisible(true);	
	}
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.event.ActionListener.actionPerformed(ActionEvent e)
	 */
	@Override
	public void actionPerformed(ActionEvent e) {	
		//Plant p = null;
		//Meat m = null;
		if(e.getSource()==lettuce) {
			
			this.food= Lettuce.getInstance(pan);
			System.out.println("try eat plant");
		}
		if(e.getSource()==cabbage) {
			
			this.food=Cabbage.getInstance(pan);
		}
		if(e.getSource()==meat) {
			this.food= Meat.getInstance(pan);			
		}
		setVisible(false);
		if(this.food!=null) {
			food.setOnPanel(true);
			this.pan.setFood(food);
			this.pan.setFoodType(food.getFoodtype());
		}
	
		
		//pan.manageZoo();
		System.out.println(this.food);
		pan.repaint();
	}
}
