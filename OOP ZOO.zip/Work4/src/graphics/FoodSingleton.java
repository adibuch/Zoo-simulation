package graphics;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;

import food.EFoodType;
import food.IEdible;
import mobility.ILocatable;
import mobility.Point;
import plants.Cabbage;
import plants.Lettuce;
import plants.Plant;

public abstract class FoodSingleton implements IEdible, ILocatable, IDrawable {

	    protected static volatile FoodSingleton instance = null;
		private BufferedImage img1;
		private double height;
		private boolean onPanel;
		private Point location;
		private double weight;
		protected ZooPanel pan;
		private String col;
		
		
		/******************************************************
		 *                   CONSTRUCTORS                     *
		 ******************************************************/		
		
	   protected FoodSingleton(ZooPanel panel) {
		   this.pan=panel;
		   Random rand = new Random();
		   int x = rand.nextInt(30);
		   int y = rand.nextInt(12);
		   this.location = new Point(x, y);
		   this.height = rand.nextInt(30);
		   this.weight = rand.nextInt(12);
		   this.onPanel = false;
		   pan.setEnabled(true);
	   }
	   
	 

		
		/******************************************************
		 *                     GETTERS                        *
		 ******************************************************/

		/**
		 * Method that returns the height of the Plant
		 * @return 
		 * 		- the height of the Plant
		 */
		public double getHeight() {
			
			return this.height;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see mobility.ILocatable#getLocation()
		 */
		@Override
		public Point getLocation() {
			
			return this.location;
		}

		/**
		 * Method that returns the weight of the Plant
		 * @return 
		 * 		- the weight of the Plant
		 */
		public double getWeight() {
			
			return weight;
		}
		public void setInstanceToNull() {
			 instance=null;
		}

		/**
		 * Method that returns if the Plant appears on the main Panel
		 * @return 
		 * 		- if the Plant appears on the main Panel : True
		 * 		  otherwise : False
		 */
		public boolean isOnPanel() {
			return onPanel;
		}


		/*
		 * (non-Javadoc)
		 * 
		 * @see graphics.IDrawable#getColor()
		 */
		@Override
		public String getColor() {
			return this.col;
			
		}
		
		public BufferedImage getImage() {
			return this.img1;
		}
		
		/******************************************************
		 *                     SETTERS                        *
		 ******************************************************/
		
		/**
		 * Method for setting the height of the Plant
		 * @param height 
		 * 				- The height of the Plant
		 * @return - If the setting was made : True,
		 * 			 Otherwise : False
		 */			 
		public boolean setHeight(double height) {

			boolean isSuccess = (height >= 0);
			if (isSuccess) {
				this.height = height;
			} else {
				this.height = 0;
			}
			return isSuccess;
		}
		
		public void setImage(BufferedImage img) {
			this.img1 = img;
		}
		
		/**
		 * Method for setting the weight of the Plant
		 * @param weight 
		 * 				- The weight of the Plant
		 * @return - If the setting was made : True,
		 * 			 Otherwise : False
		 */	
		public boolean setWeight(double weight) {
			boolean isSuccess = (weight >= 0);
			if (isSuccess) {
				this.weight = weight;
			} else {
				this.weight = 0;
			}
			return isSuccess;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see mobility.ILocatable#setLocation(mobility.Point)
		 */
		@Override
		public boolean setLocation(Point newLocation) {
			boolean isSuccess = Point.cheackBounderies(newLocation);
			if (isSuccess) {
				this.location = newLocation;
			}
			return isSuccess;
		}


		/**
		 * A method that sets the image of the Plant
		 * @param link - 
		 * 				Name the image without the path to it and without the image type
		 */
		public void setImag1(String link) {
			 
			try {
				if(link.equals("Meat"))
					this.img1 = ImageIO.read(new File(PICTURE_PATH+link+".gif"));
				else {
					this.img1 = ImageIO.read(new File(PICTURE_PATH+link+".png"));
				}
				
				}
			catch (IOException e) { System.out.println("Cannot load image"); }
		}
		
		/**
		 * A method that sets whether the Plant appears on the panel
		 * @param bool 
		 */
		public void setOnPanel(boolean bool) {
			this.onPanel = bool;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see graphics.IDrawable#drawObject(Graphics g)
		 */
		@Override
		public void drawObject (Graphics g){
			g.drawImage(this.getImage(),(this.pan.getWidth()-50)/2,(this.pan.getHeight()-50)/2,50,50 , this.pan);	
		}

}
