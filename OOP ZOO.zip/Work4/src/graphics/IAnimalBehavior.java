package graphics;

/**
 * An interface that describes the functionality of animals behavior.
 * @version April 2022
 * @author  Adi Buchris 206147647
 * 			Demi Netzer 323134577
 */
public interface IAnimalBehavior {
	
	/**
	 * Method for returning the name of the animal
	 * @return - Name of the Animal
	 */
	public String getAnimalName();
	
	/**
	 * Method for returning the size of the animal 
	 * @return - Size of the Animal
	 */
	public int getSize();
	
	/**
	 * A method that increases by 1 the amount of times the animal has eaten
	 */
	public void eatInc();
	
	/**
	 * Method for returning the amount of times the animal has eaten 
	 * @return - The amount of times the animal has eaten
	 */
	public int getEatCount();
	
	/**
	 * A method that returns if a change in the location 
	 * of the animal has been made
	 * @return - if a change in the position of the animal has been made : True,
	 * 			 otherwise : False
	 */
	public boolean getChanges ();
	
	/**
	 * Method for setting if the location of the
	 * animal has changed
	 * @param state
	 * 				- boolean state 
	 */
	public void setChanges (boolean state);
	public void setSuspended();
	public  void setResumed();
}
