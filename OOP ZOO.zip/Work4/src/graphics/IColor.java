package graphics;

public interface IColor {
	
	public void setColor(String color);	

}
