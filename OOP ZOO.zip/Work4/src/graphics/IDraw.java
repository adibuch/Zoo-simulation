package graphics;

public interface IDraw {
	
	public  void draw(String color);
}
