package graphics;
import java.awt.Graphics;

/**
 * An interface that describes the functionality of drawing objects.
 * @version April 2022
 * @author  Adi Buchris 206147647
 * 			Demi Netzer 323134577
 */
public interface IDrawable {
	
	public final static String PICTURE_PATH = "C:\\Users\\Administrator\\eclipse-workspace\\zooTread\\src\\graphics\\";
	
	/**
	 * Method for loading an image
	 * @param nm 
	 * 			- Color of the image
	 */
	public void loadImages(String nm);
	
	/**
	 * Method for drawing an object
	 * @param g
	 */
	public void drawObject (Graphics g);
	
	/**
	 * Method for getting the color of the object
	 * @return
	 * 			- the color of the object
	 */
	public String getColor();	
	
}
