package graphics;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import javax.imageio.ImageIO;
import food.EFoodType;
import food.IEdible;
import mobility.ILocatable;
import mobility.Point;

/**
 * A class that defines a Meat.
 * @version April 2022
 * @author  Adi Buchris
 * 			Demi Netzer
 */
public  class Meat  extends FoodSingleton implements IEdible, ILocatable, IDrawable {
		
	
	/******************************************************
	 *                   CONSTRUCTORS                     *
	 ******************************************************/
	
	/**
	 * Constructor
	 * @param panel
	 * 				- the main panel
	 */
	protected Meat(ZooPanel panel) {
		super(panel);
	}

	 public static FoodSingleton getInstance(ZooPanel panel){
	       if (FoodSingleton.instance == null)
	          synchronized(FoodSingleton.class){   
	              if (instance == null)
	                  instance = new Meat(panel);
	          }
	       return instance;
	 }
	
	/******************************************************
	 *                     GETTERS                        *
	 ******************************************************/
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see food.IFood#getFoodtype()
	 */
	@Override
	public EFoodType getFoodtype() {
		return EFoodType.MEAT;
	}

	
	/******************************************************
	 *                  OTHER METHODS                     *
	 ******************************************************/
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see  graphics.IDrawable#loadImages(String nm)
	 */
	@Override
	public void loadImages(String nm) {
		this.setImag1(nm);
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "[" + this.getClass().getSimpleName() + "] ";
	}
}
