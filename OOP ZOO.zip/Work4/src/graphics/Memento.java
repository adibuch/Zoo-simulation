package graphics;

import java.awt.image.BufferedImage;
import java.util.concurrent.CopyOnWriteArrayList;

import animals.Animal;

public interface Memento {


}
