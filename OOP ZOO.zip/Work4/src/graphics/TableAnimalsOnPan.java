package graphics;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.swing.*;
import javax.swing.table.JTableHeader;
import animals.Animal;

/**
 * A class for creating a table for animals information  
 * @version April 2022
 * @author  Adi Buchris 206147647
 * 			Demi Netzer 323134577
 */
public class TableAnimalsOnPan extends JFrame{
 
	final String column[]={"Animal","Color","Weight","Hor. Speed","Ver. Speed","Eat Counter"};
	private JButton btmBack;
	
	/**
	 * constructor
	 * @param arr 
	 * 			- An array of animals  
	 */
	public  TableAnimalsOnPan(CopyOnWriteArrayList<Animal> animals){ 
		
		JPanel f=new JPanel();    
		String data[][]=new String [animals.size()+1][column.length]; 
		int total = 0; // The total amount of times animals ate
		int i=0,j;
		

		for ( i = 0 ; i < animals.size() ; i++) {
			// Copy details of animals to the table
			j=0;
			data[i][j++]=animals.get(i).getAnimalName();
			data[i][j++]=animals.get(i).getColor();
			data[i][j++]=String.valueOf(animals.get(i).getWeight());
			data[i][j++]=String.valueOf(animals.get(i).getHorSpeed());
			data[i][j++]=String.valueOf(animals.get(i).getVerSpeed());
			data[i][j++]=String.valueOf(animals.get(i).getEatCount());
			total += animals.get(i).getEatCount();
		}
		

		data[animals.size()][0] = "Total";
		data[animals.size()][column.length -1] = String.valueOf(total);
		
		JTable jt=new JTable(data,column);
		jt.setGridColor(Color.BLACK);
		jt.setFont(new Font("David",Font.PLAIN,14));
		jt.setBounds(50,50,200,300);  
		
		JTableHeader tbh=jt.getTableHeader();
		tbh.setFont(new Font("David",Font.BOLD,16));
		        
		JScrollPane sp=new JScrollPane(jt); 
		sp.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
		
		btmBack=new JButton("Back to zoo");
		btmBack.setFont(new Font("David",Font.BOLD,16));
		
		// Back to zoo
		btmBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg) {
				setVisible(false);     
			}});
		
		f.setLayout(new BorderLayout());
		f.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
		f.add(sp,BorderLayout.CENTER);
		f.add(btmBack,BorderLayout.SOUTH);
		
		add(f);
		setSize(1200,500);    
		setVisible(true);     
	}
}
