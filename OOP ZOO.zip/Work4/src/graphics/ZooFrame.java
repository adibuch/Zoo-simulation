package graphics;

import java.awt.BorderLayout;
import java.*;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.swing.*;

/**
 * A class for creating the main frame of the zoo  
 * @version April 2022
 * @author  Adi Buchris 206147647
 * 			Demi Netzer 323134577
 */
public class ZooFrame extends JFrame implements ActionListener {
	
	

	private ZooPanel panel = ZooPanel.getInstance();
	JMenuItem exit, image, green, none, actualHelp;
	JMenuBar menu;
	JMenu file, background, help;
	JLabel imageLabel = new JLabel();
	private BufferedImage imageBack=null;
	//private Caretaker zoo=new Caretaker();;
	
	
	
	/**
	 * Constructor
	 */
	public ZooFrame() {
		this.setTitle("Zoo");
		
		this.setSize(800,600);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		imageLabel.setIcon(new ImageIcon(IDrawable.PICTURE_PATH+"savanna.png"));
		
		menu = new JMenuBar();
		this.add(menu, BorderLayout.NORTH);
		
		file = new JMenu("File");
		menu.add(file);

		background = new JMenu("Background");
		menu.add(background);

		help = new JMenu("Help");
		menu.add(help);
		
		exit = new JMenuItem("Exit");
		file.add(exit);
		exit.addActionListener(this);
		
		image = new JMenuItem("Image");
		background.add(image);
		image.addActionListener(this);

		green = new JMenuItem("Green");
		background.add(green);
		green.addActionListener(this);
		
		none = new JMenuItem("None");
		background.add(none);
		none.addActionListener(this);
		
		actualHelp = new JMenuItem("Help");
		help.add(actualHelp);
		actualHelp.addActionListener(this);
		
		
		//panel.getThread().start();
		this.add(panel);
		this.setVisible(true);
	}

	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.event.ActionListener#actionPerformed(ActionEvent e)
	 */
	@Override
	public void actionPerformed(ActionEvent e) { 
		if(e.getSource() == exit) {
			this.panel.exit();
			System.exit(0);	
		}
		
		if(e.getSource() == image) { 
			this.panel.setImage();
			this.panel.repaint();
		}
		
		if(e.getSource() == green) {
			this.panel.setImageNull();
			panel.setBackground(Color.green);
			this.panel.repaint();
		}
		
		if(e.getSource() == none) {
			this.panel.setImageNull();
			panel.setBackground(null);
			this.panel.repaint();
		}			
		
		if(e.getSource() == actualHelp)
			JOptionPane.showMessageDialog(actualHelp,"Home Work 2\nGUI");
	}

/*
	private class WindowState implements Memento {
		private ZooPanel panel;
		private BufferedImage imageBack=null;
		private WindowState(ZooPanel panel, BufferedImage imageBack) {
			this.panel=(ZooPanel)panel.clone();
			this.imageBack=imageBack;
		}
		public  ZooPanel getObjectPanel() { return this.panel; }
		public  BufferedImage getObjectImage() { return this.imageBack; }
		
		
		}
	public Memento save() {
			//System.out.println(this.animals );
			//System.out.println(this.foodS );
			return new WindowState(this.panel,this.imageBack);
			
		}
	public void restore(Memento state) {
		System.out.println(((WindowState)state).getObjectPanel().getFoodType() );
		this.panel = ((WindowState)state).getObjectPanel();
		this.imageBack = ((WindowState)state).getObjectImage();
	}
	public Caretaker getCaretaker() {
		return this.zoo;
	}
			/*for (int i=0;i<this.animals.size();++i) {
				animals.get(i).setAlive(false);
			}
			this.animals = ((WindowState)state).getObjectAnimal();
			for (int i=0;i<this.animals.size();++i) {
				this.e.execute(animals.get(i));this.repaint();
			}
			System.out.println(state );
			System.out.println(this.animals );
			this.foodS = ((WindowState)state).getObjectFood();
			this.e=((WindowState)state).getE();
			this.foodType=((WindowState)state).getFoodType();
			this.total=((WindowState)state).getTotal();
			this.imgSavanna=((WindowState)state).getImage();
			this.Suspended=((WindowState)state).getSus();
			this.isAlive=((WindowState)state).getAlive();
			
		}
	
	/**
	 * Main method
	 */
	public static void main(String[] args) {
	      SwingUtilities.invokeLater(new Runnable() {
	         public void run() {
	        	 new ZooFrame();
	         }
	      });
	  }
}
