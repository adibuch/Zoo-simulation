package graphics;

import java.awt.BorderLayout;


import animals.Animal;
import food.EFoodType;
import food.IEdible;

import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.imageio.ImageIO;
import javax.swing.*;

/**
 * A class for creating the main panel of the zoo  
 * @version April 2022
 * @author  Adi Buchris 206147647
 * 			Demi Netzer 323134577
 */
public class ZooPanel extends JPanel implements ActionListener {
	
    static private volatile ZooPanel instance = null;
	public final static int THREAD_COUNT = 2;
	private JButton btAddAnimal,btSetColor,btSleep,btWakeUp,btClear,btFood,btInfo,btSave,btRecovery,btExit;
	private CopyOnWriteArrayList<Animal> animals=null;//animal array
	private EFoodType foodType=null;
	private  Image imgSavanna =null;
	private int total = 0;
	//private Thread controller; 
	private boolean Suspended;
	private boolean isAlive=true;
	private ExecutorService e = Executors.newFixedThreadPool(THREAD_COUNT);
	private FoodSingleton foodS;
	private Caretaker zoo = new  Caretaker(this);
	private Controller controller;

	//private ZooFrame frame;
	

	
	/******************************************************
	 *                   CONSTRUCTORS                     *
	 ******************************************************/
	
	/**
	 * Constructor
	 */
	private  ZooPanel(/*ZooFrame frame*/) {

		controller = new Controller(this);

		// Initialize arrays
		animals=new CopyOnWriteArrayList<Animal>(); 
		
		
		// Initialize buttons
		btAddAnimal= new JButton("Add Animal");
		btAddAnimal.addActionListener(this);
		
		btSetColor= new JButton("Set color");
		btSetColor.addActionListener(this);
		
		btSleep= new JButton("Sleep");
		btSleep.addActionListener(this);
		
		btWakeUp= new JButton("Wake up");
		btWakeUp.addActionListener(this);
		
		btClear= new JButton("Clear");
		btClear.addActionListener(this);
		
		btFood= new JButton("Food");
		btFood.addActionListener(this);

		btInfo= new JButton("Info");
		btInfo.addActionListener(this);
		
		btSave= new JButton("Save");
		btSave.addActionListener(this);
		
		btRecovery= new JButton("Recovery");
		btRecovery.addActionListener(this);

		btExit= new JButton("Exit");
		btExit.addActionListener(this);
		
		// Create a new panel for buttons
		JPanel p1=new JPanel();
		p1.setLayout(new GridLayout(1,10));

		p1.add(btAddAnimal);
		p1.add(btSetColor);
		p1.add(btSleep);
		p1.add(btWakeUp);
		p1.add(btClear);
		p1.add(btFood);
		p1.add(btInfo);
		p1.add(btSave);
		p1.add(btRecovery);
		p1.add(btExit);

		this.setLayout(new BorderLayout());
		this.add(p1,BorderLayout.SOUTH);
		this.setBorder(BorderFactory.createEmptyBorder(0,0,0,0));
		this.setSize(800,600);
	}

    public static ZooPanel getInstance(/*ZooFrame frame*/){
       if (instance == null)
          synchronized(ZooPanel.class){   
              if (instance == null) {
                  instance = new ZooPanel();
                 // instance.controller.start();
              }
              
          }
       return instance;
    }

	
	/*public Thread getThread() {
		return this.controller;
	}*/
	public ExecutorService getQueue() {
		return e;
	}
	public void setSuspended(boolean state){
		this.Suspended = state;
	}
	public boolean getSuspended() {
		return this.Suspended;
	}

	//Memento----------------------------
	
	private class WindowState implements Memento {
		private CopyOnWriteArrayList<Animal> newAnimals=new CopyOnWriteArrayList<Animal>();;
		private FoodSingleton food;
		private ExecutorService e;
		private int total;
		private EFoodType foodType;
		private Image imgSavanna;
		private boolean Suspended;
		private boolean isAlive;
		private Controller controller;
		private WindowState(CopyOnWriteArrayList<Animal> animals,FoodSingleton food,ExecutorService e,int total,
				EFoodType foodType,Image imgSavanna,boolean Suspended,boolean isAlive,Controller controller) {
			for(int i =0; i < animals.size(); i++) {
				newAnimals.add((Animal) animals.get(i).clone());
			}
			 this.food=food; 
			 this.e=e;
			 this.total=total;
			 this.foodType=foodType;
			 this.imgSavanna=imgSavanna;
			 this.Suspended=Suspended;
			 this.isAlive=isAlive;
			 this.controller=(Controller) controller.clone();
		}
		public  CopyOnWriteArrayList<Animal> getObjectAnimal() { return this.newAnimals; }
		public  FoodSingleton getObjectFood() { return this.food; }
		public ExecutorService getE() {return this.e;}
		public int getTotal() {return this.total;}
		public EFoodType getFoodType(){return this.foodType;}
		public Image getImage() {return this.imgSavanna;}
		public boolean getSus() {return this.Suspended;}
		public boolean getAlive() {return this.isAlive;}
		public Controller getController() {return this.controller;}
		
		@Override
		public String toString() {
			String str="";
			for(int i =0; i < newAnimals.size(); i++) {
				str+=newAnimals.get(i);
			}
			str+=this.food;
			return str;
		}
		}
	
	
	public Memento save() {
			
			return new WindowState(this.animals,this.foodS,this.e,this.total,this.foodType,
					this.imgSavanna,this.Suspended,this.isAlive,this.controller);
			
		}
	
	
	public void restore(Memento state) {
		
			for (int i=0;i<this.animals.size();++i) {
				animals.get(i).setAlive(false);
			}
			System.out.println(state );
			this.animals = ((WindowState)state).getObjectAnimal();
			
			System.out.println(this.animals );
			this.foodS = ((WindowState)state).getObjectFood();
			this.e=((WindowState)state).getE();
			this.foodType=((WindowState)state).getFoodType();
			this.total=((WindowState)state).getTotal();
			this.imgSavanna=((WindowState)state).getImage();
			this.Suspended=((WindowState)state).getSus();
			this.isAlive=((WindowState)state).getAlive();
			this.controller=((WindowState)state).getController();
			for (int i=0;i<this.animals.size();++i) {
				this.e.execute(animals.get(i));
				animals.get(i).addObserver(controller);
			}
			this.repaint();
		}

	
	/******************************************************
	 *                  OTHER METHODS                     *
	 ******************************************************/
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.awt.event.ActionListener#actionPerformed(ActionEvent e)
	 */
	@Override
	public void actionPerformed(ActionEvent e) {	
		
		if(e.getSource()==btAddAnimal) {
			if (animals.size() == 15)
				JOptionPane.showMessageDialog(btAddAnimal,"You cannot add more than 15 animals");				
			else {
				new AddAnimalDialog(animals, this);
				
			}
		}
		if(e.getSource()==btSetColor) {
			if (animals.size() == 0)
				JOptionPane.showMessageDialog(btSetColor,"Sorry, there are no animals in the zoo\n");				
			else {
				new Color(animals, this);
				
			}
		}
		if(e.getSource()==btSleep) {
			for (Animal i : animals) {
				i.setSuspended();
			}
			this.Suspended=true;
		}
		
		if(e.getSource()==btWakeUp) {
			for (Animal i : animals) {
				i.setResumed();
			}
			this.Suspended=false;
			for(Animal i: animals) {
				if(this.Suspended==false) {
				    synchronized(i) {
				    	if(this.Suspended==false) {
				    	i.notify();
				    	}
				    }
				}
			}
		
		}
		
		if(e.getSource()==btClear) {
			synchronized(this) {
				int size=Math.min(THREAD_COUNT,animals.size());
				for (int i=0;i<size;++i) {
					animals.get(i).setAlive(false);
				}
				while (size!=0) {
					
					if(!animals.get(0).getAlive()) {
						animals.remove(0);
						System.out.println(animals);
					}
					--size;
				}
			}
			
			
			for (int i=0;i<animals.size();++i) {
				System.out.println(animals.get(i));
				
			}
			JOptionPane.showMessageDialog(btClear,"All animals have been deleted");
			this.repaint();
			
		}
		
		if (e.getSource()==btInfo) {
			if(animals.size()==0) {
				JOptionPane.showMessageDialog(btAddAnimal,"Sorry, there are no animals in the zoo\n" );
			}
			else {
				new TableAnimalsOnPan(animals);
			}
		}
		
		if(e.getSource()==btFood) {
			if (foodS != null)
				JOptionPane.showMessageDialog(btFood,"You cannot add more food");				
			else {
				new Food(foodS,this);
				System.out.println("try eat plant");
				//tryEatAnimal();
				//tryEatFood();
			}
		}
		if(e.getSource()==btSave) {
			if(this.zoo.getSize()==3)
				JOptionPane.showMessageDialog(btSave,"You cannot add more state");	
			else
				{this.zoo.hitSave();
				JOptionPane.showMessageDialog(btSave,"Saved!");	
				
				}
			
			
			
			
		}
		if(e.getSource()==btRecovery) {
			if(this.zoo.getSize()==0)
				JOptionPane.showMessageDialog(btRecovery,"There are no recovery modes");	
			else
				this.zoo.hitUndo();
			
		}
		
		if(e.getSource()==btExit) {
			this.exit();
		}
	}
	
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.swing.JComponent#paintComponent(Graphics g)
	 */
	@Override
	public void paintComponent(Graphics g) {
		 super.paintComponent(g) ;
		
		System.out.println("paincOMM") ;
	     if(imgSavanna!=null)
	           g.drawImage(imgSavanna,0,0,getWidth(),getHeight(), this);
		
		 if(animals.size()>0) {
			 synchronized(animals) {
				 int size=Math.min(THREAD_COUNT,animals.size());
				 for (int i=0;i<size;++i) {
							if(animals.get(i)!=null)
					 		if(animals.get(i).isOnPanel()==true) {
					 			animals.get(i).loadImages(animals.get(i).getColor());
					 			animals.get(i).drawObject(g);
							}
						}
				}
			
			}
			
			if(foodS!=null) { 
				synchronized(foodS) {
					if(foodS!=null) { 
						if(foodS.isOnPanel()==true) {
							foodS.loadImages(foodS.getClass().getSimpleName());
							foodS.drawObject(g);
							System.out.println(this.foodS);
						}
					}
				
			 } 			 
		 }
	}
	
	
	/**
	 * A method that checks for all animals if there is an animal
	 * that can eat another animal, and if so it eats it
	 */
	public synchronized void tryEatAnimal() {
		int size=Math.min(THREAD_COUNT,animals.size());
		synchronized(this.animals) {
	
			for (int i = 0; i < size; i++) {
				for( int j = 0; j < size; j++ ) {
					
						boolean canEatAnimal=(j!=i&&animals.get(i).isOnPanel()==true && 
								animals.get(i).getMobile().calcDistance(animals.get(j).getMobile().getLocation()) < animals.get(j).getSize() &&
								animals.get(i).getDiet().canEat(animals.get(j).getFoodtype()) &&
								animals.get(i).getWeight() > 2*animals.get(j).getWeight());
					if(canEatAnimal) {
						//animals.get(i).move(animals.get(j).getLocation());
						animals.get(i).eat(animals.get(j));
						animals.get(j).setAlive(false);
						animals.get(j).setOnPanel(false);
						animals.remove(j);
						if (j < i) i-=1; 
						j-=1;
					
				
					}
				}
				}
		}
	}
	
	public Object clone() {
		ZooPanel current = new ZooPanel();
		for(int i =0; i < this.animals.size(); i++) {
			current.animals.set(i, (Animal) this.animals.get(i).clone());
		}
		current.setFoodType(this.getFoodType());
		if (this.total > 0) {current.setTotal();}
		current.setSuspended(this.getSuspended());
		current.setFood(this.foodS);
		return current;
	}
	

	
	/**
	 * A method that checks for all animals if there is an animal that
	 * can eat food, and if so the nearest animal eats it
	 */
	public void tryEatFood(Animal animal) {

		System.out.println("im here");
		if(foodS!= null) {
			synchronized(foodS) {
				if(foodS!= null) {
					System.out.println("try eat plant");
					if(animal.eat(foodS)) {
						foodS.setInstanceToNull();
						foodS=null;
						//this.repaint();
						animal.setChanges(false);
					}
				}
				}
		}
	
		synchronized(this.foodType) {
			this.foodType = null;
		}
        //this.repaint();
	}
	
	
	
	/*public void setFood(boolean eat) {
		if(eat) {
			this.plant=null;
			this.meat=null;
		}
	}*/
	/**
	 * A method that manages the zoo
	 * and everything that appears in it
	 */
	/*public void run() {
		while(isAlive) {
			
				
			this.tryEatAnimal();
			repaint();
			}
		
	}*/
	
	

	
	/******************************************************
	 *                     SETTERS                        *
	 ******************************************************/
	
	/**
	 * A method that sets the zoo background image to null
	 */
	public void setImageNull() {
		this.imgSavanna=null;
	}
	
	/**
	 * A method that loads the background image of the zoo
	 */
	public void setImage() {
		try { 
			this.imgSavanna= ImageIO.read(new File(IDrawable.PICTURE_PATH +"savanna.png")); 
		}
		catch (Exception ex) { System.out.println("Cannot load image"); }
	}	
	
	
	
	
	/**
	 * A method that sets the type of food that appears in the zoo
	 * @param food - type of food
	 */
	public void setFoodType(EFoodType food) {
		this.foodType=food;
	}
	/**
	 * A method that returns the type of food in the zoo
	 * @return EFoodType
	 */
	public EFoodType getFoodType() {
		return this.foodType;
	}
	
	/**
	 * A method that increases by 1 the amount of food in the zoo
	 */
	public synchronized void setTotal() {
		this.total+=1;
	}
	/**
	 * A method that returns the food in the zoo
	 * @return IEdible
	 */
	public IEdible getFood() {
		if(foodS!=null)
			return foodS;
		return null;
	}
	/**
	 * A method that sets the plant that appears in the zoo
	 * @param p - plant
	 */
	public void setFood(FoodSingleton f) {
		 this.foodS=f;
	}


	/**
	 * A method that sets if the thread is alive
	 * @param alive - boolean
	 */
	public void setAlive(boolean alive) {
		this.isAlive=alive;
	}
	
	public boolean isAlive() {
		return this.isAlive;
	}
	
	public Controller getController() {
		return this.controller;
	}

	public void exit() {
		
		synchronized(animals) {
			for (Animal i: animals) {
				i.setAlive(false);
			}
			this.isAlive=false;
		}
		this.e.shutdown();
		System.exit(0);
		
	}
	
	

}


	
