package plants;

import graphics.FoodSingleton;
import graphics.Meat;
import graphics.ZooPanel;

/**
 * A class that defines a Cabbage.
 * @version April 2022
 * @author  Adi Buchris
 * 			Demi Netzer
 */
public class Cabbage extends Plant {
	
	protected Cabbage(ZooPanel pan) {
		super(pan);
	}
	
	 public static FoodSingleton getInstance(ZooPanel panel){
	       if (FoodSingleton.instance == null)
	          synchronized(FoodSingleton.class){   
	              if (instance == null)
	                  instance = new Cabbage(panel);
	          }
	       return instance;
	 }
}
