package plants;



import food.EFoodType;
import food.IEdible;
import graphics.FoodSingleton;
import graphics.IDrawable;
import graphics.ZooPanel;
import mobility.ILocatable;


/**
 * A class that defines a Plant.
 * @version April 2022
 * @author  Adi Buchris
 * 			Demi Netzer
 */
public abstract class Plant extends FoodSingleton implements IEdible, ILocatable, IDrawable {
	
	public final static String[] plant= {"cabbage","lettuce"};
		
	/******************************************************
	 *                   CONSTRUCTORS                     *
	 ******************************************************/

	/**
	 * Constructor
	 * @param panel - The main panel 
	 */
	protected Plant(ZooPanel panel) {
		super(panel);
	}

	
	/******************************************************
	 *                     GETTERS                        *
	 ******************************************************/
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see food.IFood#getFoodtype()
	 */
	@Override
	public EFoodType getFoodtype() {	
		return EFoodType.VEGETABLE;
	}

	
	/******************************************************
	 *                  OTHER METHODS                     *
	 ******************************************************/
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see  graphics.IDrawable#loadImages(String nm)
	 */
	@Override
	public void loadImages(String nm) {
		
		if (nm.equals("Cabbage") ) {
			this.setImag1(plant[0]);
		}
		if (nm.equals("Lettuce") ) {
			this.setImag1(plant[1]);
		}
	}
	
		
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "[" + this.getClass().getSimpleName() + "] ";
	}
}
